<script setup lang="ts"></script>
<template>
  <div class="flex justify-center items-center h-[80vh]">
    <div class="text-center">
      <img
        class="block"
        src="https://vuejsforge.com/images/logo.svg"
        alt="Vue.js Forge"
      />
      <AppButton class="block">
        <a href="https://vi.to/hubs/vueforge" target="_blank">Get Started</a>
      </AppButton>
    </div>
  </div>
</template>
